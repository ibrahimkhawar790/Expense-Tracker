// Array to store our expense objects
let expenses = [];

// DOM Elements
let descInput = document.getElementById('desc');
let amountInput = document.getElementById('amount');
let categoryInput = document.getElementById('category');
let addBtn = document.getElementById('add-btn');
let expenseList = document.getElementById('expense-list');
let totalAmountEl = document.getElementById('total-amount');
let budgetInput = document.getElementById('budget');
let descError = document.getElementById('desc-error');
let amountError = document.getElementById('amount-error');
let sortToggle = document.getElementById('sort-toggle');
let categorySummary = document.getElementById('category-summary');

// 1. Event Listeners for Adding Expenses
addBtn.addEventListener('click', addExpense);

// Trigger add on 'Enter' key
descInput.addEventListener('keydown', function(event) {
    if (event.key === 'Enter') addExpense();
});
amountInput.addEventListener('keydown', function(event) {
    if (event.key === 'Enter') addExpense();
});

// Live Updates when budget or sort changes
budgetInput.addEventListener('input', renderList);
sortToggle.addEventListener('change', renderList);

// 2. Add Expense Logic with Validation
function addExpense() {
    let descValue = descInput.value.trim();
    let amountValue = parseFloat(amountInput.value);
    let categoryValue = categoryInput.value;
    let isValid = true;

    // Field-level error validation
    if (descValue === "") {
        descError.innerText = "Please enter a description.";
        isValid = false;
    } else {
        descError.innerText = "";
    }

    if (isNaN(amountValue) || amountValue <= 0) {
        amountError.innerText = "Amount must be greater than 0.";
        isValid = false;
    } else {
        amountError.innerText = "";
    }

    if (!isValid) return; // Stop execution if validation fails

    // Create unique ID using current timestamp
    let newExpense = {
        id: Date.now(),
        desc: descValue,
        amount: amountValue,
        category: categoryValue
    };

    expenses.push(newExpense);

    // Clear inputs
    descInput.value = '';
    amountInput.value = '';
    descInput.focus();

    // Redraw the interface
    renderList();
}

// 3. Delete Expense Logic
function deleteExpense(id) {
    let tempExpenses = [];
    // Basic loop to filter out the deleted item
    for (let i = 0; i < expenses.length; i++) {
        if (expenses[i].id !== id) {
            tempExpenses.push(expenses[i]);
        }
    }
    expenses = tempExpenses;
    renderList(); // Realtime total recalculation
}

// 4. Edit In Place Logic (Switching text nodes to <input>)
function enableInlineEdit(liElement, expenseObj) {
    // Save original HTML in case user presses Escape
    let originalHTML = liElement.innerHTML;

    // Replace inner HTML with inputs
    liElement.classList.add('edit-mode');
    liElement.innerHTML = `
        <div class="expense-info">
            <input type="text" id="edit-desc-${expenseObj.id}" value="${expenseObj.desc}">
            <input type="number" id="edit-amount-${expenseObj.id}" value="${expenseObj.amount}" min="0.01" step="0.01">
        </div>
        <div>
            <button class="action-btn save-btn">Save</button>
            <button class="action-btn cancel-btn">Cancel</button>
        </div>
    `;

    let editDescInput = document.getElementById(`edit-desc-${expenseObj.id}`);
    let editAmountInput = document.getElementById(`edit-amount-${expenseObj.id}`);
    let saveBtn = liElement.querySelector('.save-btn');
    let cancelBtn = liElement.querySelector('.cancel-btn');

    // Auto-focus the description
    editDescInput.focus();

    // Function to save changes
    function saveChanges() {
        let newDesc = editDescInput.value.trim();
        let newAmount = parseFloat(editAmountInput.value);

        if (newDesc !== "" && !isNaN(newAmount) && newAmount > 0) {
            expenseObj.desc = newDesc;
            expenseObj.amount = newAmount;
            renderList(); // Re-render applies changes and updates total immediately
        } else {
            alert("Invalid input. Description cannot be empty and amount must be > 0.");
        }
    }

    // Function to cancel
    function cancelChanges() {
        renderList(); // Simple re-render resets to original state
    }

    // Attach listeners to new inline buttons
    saveBtn.addEventListener('click', saveChanges);
    cancelBtn.addEventListener('click', cancelChanges);

    // Keydown handling for Enter and Escape
    function handleKey(event) {
        if (event.key === 'Enter') saveChanges();
        if (event.key === 'Escape') cancelChanges();
    }

    editDescInput.addEventListener('keydown', handleKey);
    editAmountInput.addEventListener('keydown', handleKey);
}

// 5. Render, Total Calculation, and Formatting
function renderList() {
    expenseList.innerHTML = '';
    let total = 0;
    let categoryTotals = { Food: 0, Transport: 0, Shopping: 0, Health: 0, Other: 0 };

    // Handle optional sorting
    let displayArray = expenses.slice(); // Copy array
    if (sortToggle.checked) {
        displayArray.sort(function(a, b) {
            return a.amount - b.amount; // Ascending order
        });
    }

    // Build the list and calculate totals
    for (let i = 0; i < displayArray.length; i++) {
        let currentExp = displayArray[i];
        
        // Accumulate totals
        total += currentExp.amount;
        categoryTotals[currentExp.category] += currentExp.amount;

        // Create List Item
        let li = document.createElement('li');
        
        li.innerHTML = `
            <div class="expense-info">
                <span class="desc-text">${currentExp.desc}</span>
                <span class="badge">${currentExp.category}</span>
            </div>
            <div>
                <span class="amount-text">${currentExp.amount.toFixed(2)} PKR</span>
                <button class="action-btn edit-btn">Edit</button>
                <button class="action-btn delete-btn">Delete</button>
            </div>
        `;

        // Attach event listeners to buttons
        let deleteBtn = li.querySelector('.delete-btn');
        let editBtn = li.querySelector('.edit-btn');

        deleteBtn.addEventListener('click', function() {
            deleteExpense(currentExp.id);
        });

        editBtn.addEventListener('click', function() {
            enableInlineEdit(li, currentExp);
        });

        expenseList.appendChild(li);
    }

    // Update the UI with computed values
    totalAmountEl.innerText = total.toFixed(2); // Number formatting
    
    // Conditional styling based on computed values
    let dailyBudget = parseFloat(budgetInput.value) || 0;
    if (total > dailyBudget && dailyBudget > 0) {
        totalAmountEl.classList.add('over-budget');
    } else {
        totalAmountEl.classList.remove('over-budget');
    }

    // Generate Optional Category Percentage Summary
    let summaryText = "";
    if (total > 0) {
        for (let cat in categoryTotals) {
            if (categoryTotals[cat] > 0) {
                let percent = ((categoryTotals[cat] / total) * 100).toFixed(1);
                summaryText += `<div>${cat}: ${categoryTotals[cat].toFixed(2)} PKR (${percent}%)</div>`;
            }
        }
    }
    categorySummary.innerHTML = summaryText;
}